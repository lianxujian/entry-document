module.exports = {
  NODE_ENV: '"production"',
  API_HOST:'"http://47.92.158.136:3002/"'
}
//http://47.92.147.205/apicrm/
